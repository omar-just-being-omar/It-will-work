import express from "express";
import axios from "axios";
import pkg from "pg";
import fs from "fs";
import path from "path";
import "dotenv/config";

const { Pool } = pkg;
const app = express();
const port = 3000;

// Needed because we’re using ES modules
const __dirname = path.resolve();

// Middleware
app.use(express.json());
app.use(express.static("public"))
app.use(express.static("explore"))

// PostgreSQL connection (your DB names)
const pool = new Pool({
  user: "postgres",
  host: "localhost",
  database: "World",      // ✅ your DB name
  password: "ahmed",     // adjust if needed
  port: 5432,
});

// Gemini setup
const MODEL = "gemini-1.5-flash";
const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${process.env.GEMINI_API_KEY}`;
app.get("/" , (req,res) =>{
  const filePath2 = path.join(__dirname, "public/index.html")
  res.sendFile(filePath2)
})
// Serve ai.html by reading file
app.get("/AI", (req, res) => {
  const filePath = path.join(__dirname, "public/ai.html");
  res.sendFile(filePath);
});
app.get("/explore", (req, res)=> {
  const filePath3 = path.join(__dirname, "public/explore.html");
  res.sendFile(filePath3);
})
app.get("/sun", (req, res)=> {
  const filePath4 = path.join(__dirname, "public/explore/sun.html")
  res.sendFile(filePath4)
})
app.get("/mars", (req, res)=> {
  const filePath5 = path.join(__dirname, "public/explore/mars.html")
  res.sendFile(filePath5)
})
app.get("/mercury", (req, res)=> {
  const filePath6 = path.join(__dirname, "public/explore/mercury.html")
  res.sendFile(filePath6)
})
app.get("/venus", (req, res)=> {
  const filePath6 = path.join(__dirname, "public/explore/venus.html")
  res.sendFile(filePath6)
})
app.get("/earth", (req, res)=> {
  const filePath6 = path.join(__dirname, "public/earth.html")
  res.sendFile(filePath6)
})
app.get("/asteroid", (req, res)=> {
  const filePath7 = path.join(__dirname, "public/explore/asteroid.html")
  res.sendFile(filePath7)
})
app.get("/jupiter", (req, res)=> {
  const filePath6 = path.join(__dirname, "public/explore/jupiter.html")
  res.sendFile(filePath6)
})
app.get("/saturn", (req, res)=> {
  const filePath6 = path.join(__dirname, "public/explore/saturn.html")
  res.sendFile(filePath6)
})
app.get("/uranus", (req, res)=> {
  const filePath6 = path.join(__dirname, "public/explore/uranus.html")
  res.sendFile(filePath6)
})
app.get("/neptune", (req, res)=> {
  const filePath6 = path.join(__dirname, "public/explore/neptune.html")
  res.sendFile(filePath6)
})
app.get("/kuiper", (req, res)=> {
  const filePath6 = path.join(__dirname, "public/explore/kuiper.html")
  res.sendFile(filePath6)
})
app.get("/sunt", (req, res)=> {
  const filePath6 = path.join(__dirname, "public/tests/sun.html")
  res.sendFile(filePath6)
})
app.get("/marst", (req, res)=> {
  const filePath6 = path.join(__dirname, "public/tests/mars.html")
  res.sendFile(filePath6)
})
app.get("/venust", (req, res)=> {
  const filePath6 = path.join(__dirname, "public/tests/venus.html")
  res.sendFile(filePath6)
})
app.get("/earth", (req, res)=> {
  const filePath6 = path.join(__dirname, "public/tests/earth.html")
  res.sendFile(filePath6)
})
app.get("/mercury", (req, res)=> {
  const filePath6 = path.join(__dirname, "public/tests/mercurytest.html")
  res.sendFile(filePath6)
})
app.get("/asteroidt", (req, res)=> {
  const filePath6 = path.join(__dirname, "public/tests/asteroid.html")
  res.sendFile(filePath6)
})
app.get("/jupitert", (req, res)=> {
  const filePath6 = path.join(__dirname, "public/tests/jupiter.html")
  res.sendFile(filePath6)
})
app.get("/saturnt", (req, res)=> {
  const filePath6 = path.join(__dirname, "public/tests/saturn.html")
  res.sendFile(filePath6)
})
app.get("/uranust", (req, res)=> {
  const filePath6 = path.join(__dirname, "public/tests/uranus.html")
  res.sendFile(filePath6)
})
app.get("/neptunet", (req, res)=> {
  const filePath6 = path.join(__dirname, "public/tests/neptune.html")
  res.sendFile(filePath6)
})
app.get("/kuipert", (req, res)=> {
  const filePath6 = path.join(__dirname, "public/tests/kuiper.html")
  res.sendFile(filePath6)
})
/**
 * Ask Gemini using summaries table as context
 */
async function askGemini(userQuestion, context) {
  const prompt = `
You are a helpful assistant (By the way you are a cactus fruit), and in the given for the answers,You can summarize the answers and explain it if the user asked, answer basic greetings and answers like hi, who are you ,  that ONLY answers questions about space, astronomy, rockets, satellites, some Bio ,NASA and The reference data ( it doesnt matter what the reference data is about just answer) , if there is any stats you can do some visual representation .  
If the user asks outside these topics, reply:  
"Sorry, I can only answer questions about space-related topics"

Here is some reference data from trusted websites (If the question is about the following given data use the given links as resources):  
${context.map((c) => ` Link/resources : ${c.link} Title: ${c.title}\nSummary: ${c.summary}`).join("\n\n")}

User Question: ${userQuestion}
  `;

  const response = await axios.post(GEMINI_URL, {
    contents: [{ parts: [{ text: prompt }] }],
  });

  return (
    response.data.candidates?.[0]?.content?.parts?.[0]?.text ||
    "Sorry, I couldn't generate an answer."
  );
}

// API route
app.post("/AI/ask", async (req, res) => {
  try {
    const userQuestion = req.body.question || "";

    // Get summaries from DB
    const result = await pool.query("SELECT title, summary FROM summaries");
    const context = result.rows;

    // Ask Gemini
    const answer = await askGemini(userQuestion, context);

    res.json({ answer });
  } catch (err) {
    console.error("❌ Error in /ask:", err.message);
    res.status(500).json({ error: "AI backend error" });
  }
});

app.listen(port, () =>
  console.log(`🚀 Server running at http://localhost:${port}`)
);
