let sunImg;
let grayImg;

// Sun animation variables
let x, y;
let w, h;
let startX = 700;
let startY = 850;
let targetX, targetY;
let startH = 780;
let targetH = 600;

let animationDone = false;
let animationStarted = false;

// Gray image
let grayX, grayY;
let grayTargetX, grayTargetY;
let graySize = 130;
let grayArrived = false;
let showGray = false;

// Timing
let startTime;

// --- Zoom variables ---
let zooming = false;
let earthMoveTargetX = 0;
let earthMoveTargetY = 0;
let originalEarthX = 0;
let originalEarthY = 0;
let zoomedButton = null;
let zoomScale = 1;
let targetZoomScale = 1;
let zoomCenterX = 0;
let zoomCenterY = 0;

function preload() {
  sunImg = loadImage("neptune.png");
  grayImg = loadImage("neptunem.png");
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  imageMode(CENTER);
  textSize(28);

  x = startX;
  y = startY;
  h = startH;
  w = (sunImg.width / sunImg.height) * h;

  targetX = width * 0.75;
  targetY = height / 2;

  grayX = width + 100;
  grayY = height + 100;
  grayTargetX = width - 100;
  grayTargetY = height - 100;

  startTime = millis();
  
  // Initialize zoom center to middle of screen
  zoomCenterX = width / 2;
  zoomCenterY = height / 2;
}

function draw() {
  background(0);

  if (!animationStarted && millis() - startTime >= 2000) {
    animationStarted = true;
  }

  if (animationStarted && !animationDone) {
    let dx = targetX - x;
    let dy = targetY - y;
    let distance = sqrt(dx * dx + dy * dy);
    let moveSpeed = 0.5;

    if (distance > 0.1) {
      let moveStep = moveSpeed * deltaTime;
      let ratio = moveStep / distance;
      if (ratio > 1) ratio = 1;
      x += dx * ratio;
      y += dy * ratio;
    }

    let shrinkSpeed = 133.33;
    if (h > targetH) {
      h -= shrinkSpeed * (deltaTime / 1000);
      if (h < targetH) h = targetH;
      w = (sunImg.width / sunImg.height) * h;
    }

    if (distance < 0.1 && h <= targetH) {
      animationDone = true;
      showGray = true;
      originalEarthX = x;
      originalEarthY = y;
    }
  }

  // Handle zoom
  if (zooming) {
    zoomScale = lerp(zoomScale, targetZoomScale, 0.04);

    if (abs(zoomScale - targetZoomScale) < 0.01) {
      zoomScale = targetZoomScale;
      zooming = false;
      
      // Show all buttons when zoom completes at normal scale
      if (zoomScale === 1) {
        const buttons = document.querySelectorAll(".myButton");
        buttons.forEach(b => (b.style.display = "inline-block"));
      }
    }
  }

  // Apply zoom transformation to everything
  push();
  translate(width / 2, height / 2);
  scale(zoomScale);
  translate(-zoomCenterX, -zoomCenterY);

  // ALWAYS draw earth
  image(sunImg, x, y, w, h);

  // Draw and animate gray image
  if (showGray) {
    if (!grayArrived) {
      grayX = lerp(grayX, grayTargetX, 0.08);
      grayY = lerp(grayY, grayTargetY, 0.08);

      if (dist(grayX, grayY, grayTargetX, grayTargetY) < 1) {
        grayX = grayTargetX;
        grayY = grayTargetY;
        grayArrived = true;
      }
    }
    
    // Show moon always (even when zoomed) unless zooming to a location button
    if (zoomScale < 1.5 || zoomedButton === "moon") {
      // Check if mouse is over moon (make it clickable)
      let moonScreenX = (grayX - zoomCenterX) * zoomScale + width / 2;
      let moonScreenY = (grayY - zoomCenterY) * zoomScale + height / 2;
      let moonRadius = (graySize / 2) * zoomScale;
      
      if (dist(mouseX, mouseY, moonScreenX, moonScreenY) < moonRadius && zoomScale < 1.5) {
        cursor(HAND);
      }
      
      image(grayImg, grayX, grayY, graySize, graySize);
    }
  }

  pop();

  // Draw text OUTSIDE the zoom transform (on the screen, not zoomed)
  if (animationDone && zoomScale < 1.5) {
    fill(255);
    
    // H2 - "The Blue Planet"
    textSize(20);
    textAlign(LEFT, CENTER);
    fill(150, 200, 255);
    text("The Deep Blue Planet", 20, 30);
    
    // H1 - "EARTH"
    textSize(48);
    fill(255);
    text("NEPTUNE", 20, 70);
    
    // Paragraph
    textSize(16);
    textAlign(LEFT, TOP);
    fill(200);
    let paragraph =
"    Neptune is the farthest known planet in the Solar System and is an ice giant made mainly of hydrogen, helium, and methane, which gives it a striking deep blue color. It has a faint ring system and 14 moons, with Triton being the largest, notable for its retrograde orbit and geysers of nitrogen. Neptune experiences the strongest winds in the Solar System, exceeding 2,100 km/h, and massive storms, including the Great Dark Spot. Studying Neptune’s atmosphere, rings, moons, and extreme weather helps scientists understand the dynamics and evolution of outer planets.";
    text(paragraph, 20, 110, 500);
    
    // Show "Learn More" button when viewing Earth
    const learnMoreBtn = document.getElementById('learnMoreBtn');
    if (learnMoreBtn) {
      learnMoreBtn.style.display = 'block';
    }
  } else {
    // Hide "Learn More" button when not viewing Earth
    const learnMoreBtn = document.getElementById('learnMoreBtn');
    if (learnMoreBtn) {
      learnMoreBtn.style.display = 'none';
    }
  }
  
  // Show Moon info when zoomed to moon
  if (zoomedButton === "moon" && zoomScale > 2.5) {
    fill(255);
    
    // H1 - "THE MOON"
    textSize(48);
    textAlign(LEFT, CENTER);
    text("THE MOON", 20, 70);
    
    // Moon text
    textSize(16);
    textAlign(LEFT, TOP);
    fill(200);
    let moonText = "Our Moon is essential for life on Earth. It creates the tides in our oceans, stabilizes our planet's rotation, and lights up our night sky. The gravitational pull between Earth and the Moon keeps our world in balance, creating the rhythmic ebb and flow of the seas.";
    text(moonText, 20, 130, 500);
    
    // NO "Learn More" button for moon - it stays hidden
  }
  
  // Show location info when zoomed to any location button
  if (zoomedButton && zoomedButton !== "moon" && zoomScale > 2.5) {
    fill(255);
    
    // Get button ID for title
    let locationTitle = "LOCATION";
    let textX = 20;
    let textY = 70;
    let paragraphY = 130;
    
    if (zoomedButton.id === "first") {
      locationTitle = "LOCATION 1";
      // Top right positioning
      textX = width - 520;
      textY = 70;
      paragraphY = 130;
    } else if (zoomedButton.id === "sec") {
      locationTitle = "LOCATION 2";
    } else if (zoomedButton.id === "third") {
      locationTitle = "LOCATION 3";
      // Bottom left positioning
      textX = 20;
      textY = height - 240;
      paragraphY = height - 190;
    } else if (zoomedButton.id === "fourth") {
      locationTitle = "LOCATION 4";
    }
    
    // H1 - Location title
    textSize(48);
    textAlign(LEFT, CENTER);
    text(locationTitle, textX, textY);
    
    // Location text
    textSize(16);
    textAlign(LEFT, TOP);
    fill(200);
    let locationText = "This is an important location on Earth. Each point on our planet has its own unique story, geography, and significance. From bustling cities to remote wilderness, every location contributes to the rich tapestry of our world.";
    text(locationText, textX, paragraphY, 500);
    
    // Show "Learn More" button for location
    const locationLearnMoreBtn = document.getElementById('locationLearnMoreBtn');
    if (locationLearnMoreBtn) {
      locationLearnMoreBtn.style.display = 'block';
      
      // Position button based on location
      if (zoomedButton.id === "first") {
        locationLearnMoreBtn.style.left = (width - 520) + "px";
        locationLearnMoreBtn.style.top = "280px";
        locationLearnMoreBtn.style.bottom = "auto";
      } else if (zoomedButton.id === "third") {
        locationLearnMoreBtn.style.left = "330px";
        locationLearnMoreBtn.style.top = "auto";
        locationLearnMoreBtn.style.bottom = "80px";
      } else {
        locationLearnMoreBtn.style.left = "20px";
        locationLearnMoreBtn.style.top = "280px";
        locationLearnMoreBtn.style.bottom = "auto";
      }
    }
  }
  
  // Hide location learn more button when not zoomed
  if ((!zoomedButton || zoomScale < 2.5) && document.getElementById('locationLearnMoreBtn')) {
    document.getElementById('locationLearnMoreBtn').style.display = 'none';
  }
  
  // Reset cursor if not over anything clickable
  if (zoomScale < 1.5) {
    let overMoon = false;
    if (showGray) {
      let moonScreenX = (grayX - zoomCenterX) * zoomScale + width / 2;
      let moonScreenY = (grayY - zoomCenterY) * zoomScale + height / 2;
      let moonRadius = (graySize / 2) * zoomScale;
      if (dist(mouseX, mouseY, moonScreenX, moonScreenY) < moonRadius) {
        overMoon = true;
      }
    }
    if (!overMoon) {
      cursor(ARROW);
    }
  }
}

function mousePressed() {
  // Check if clicked on moon
  if (showGray && zoomScale < 1.5 && !zooming) {
    let moonScreenX = (grayX - zoomCenterX) * zoomScale + width / 2;
    let moonScreenY = (grayY - zoomCenterY) * zoomScale + height / 2;
    let moonRadius = (graySize / 2) * zoomScale;
    
    if (dist(mouseX, mouseY, moonScreenX, moonScreenY) < moonRadius) {
      // Clicked on moon - zoom to it
      targetZoomScale = 3;
      zoomCenterX = grayX;
      zoomCenterY = grayY;
      zooming = true;
      zoomedButton = "moon"; // Special identifier
      
      // Hide all buttons
      const buttons = document.querySelectorAll(".myButton");
      buttons.forEach(b => (b.style.display = "none"));
      
      // Show home button - find it more reliably
      setTimeout(() => {
        const allButtons = document.querySelectorAll("button");
        allButtons.forEach(btn => {
          if (btn.innerHTML === "⌂") {
            btn.style.display = "block";
          }
        });
      }, 100);
    }
  }
}

// --- Buttons + effects ---
window.addEventListener("load", () => {
  // Create home button
  const homeButton = document.createElement("button");
  homeButton.innerHTML = "⌂";
  homeButton.style.cssText = `
    position: fixed;
    bottom: 30px;
    right: 30px;
    width: 50px;
    height: 50px;
    background-color: rgba(255, 255, 255, 0.1);
    color: white;
    border: 1px solid rgba(255, 255, 255, 0.3);
    border-radius: 50%;
    cursor: pointer;
    font-size: 24px;
    z-index: 1000;
    display: none;
    backdrop-filter: blur(10px);
    transition: all 0.3s ease;
  `;
  homeButton.addEventListener("mouseover", () => {
    homeButton.style.backgroundColor = "rgba(255, 255, 255, 0.2)";
    homeButton.style.transform = "scale(1.1)";
  });
  homeButton.addEventListener("mouseout", () => {
    homeButton.style.backgroundColor = "rgba(255, 255, 255, 0.1)";
    homeButton.style.transform = "scale(1)";
  });
  homeButton.addEventListener("click", () => {
    // Reset zoom
    targetZoomScale = 1;
    zoomCenterX = width / 2;
    zoomCenterY = height / 2;
    zooming = true;
    zoomedButton = null;
    
    // Show all buttons
    const buttons = document.querySelectorAll(".myButton");
    buttons.forEach(b => (b.style.display = "inline-block"));
    
    // Hide home button
    homeButton.style.display = "none";
  });
  document.body.appendChild(homeButton);

  // Create "Learn More" button
  const learnMoreBtn = document.createElement("button");
  learnMoreBtn.id = "learnMoreBtn";
  learnMoreBtn.textContent = "Learn More";
  learnMoreBtn.style.cssText = `
    position: absolute;
    left: 20px;
    top: 450px;
    background-color: #4A90E2;
    color: white;
    border: none;
    border-radius: 5px;
    padding: 10px 20px;
    cursor: pointer;
    font-size: 14px;
    font-weight: bold;
    transition: all 0.3s ease;
    display: none;
    z-index: 999;
  `;
  learnMoreBtn.addEventListener("mouseover", () => {
    learnMoreBtn.style.backgroundColor = "#357ABD";
    learnMoreBtn.style.transform = "translateY(-2px)";
  });
  learnMoreBtn.addEventListener("mouseout", () => {
    learnMoreBtn.style.backgroundColor = "#4A90E2";
    learnMoreBtn.style.transform = "translateY(0)";
  });
  learnMoreBtn.addEventListener("click", () => {
    alert("Learn more about Neptune! You can link this to more content or navigate to another page.");
  });
  document.body.appendChild(learnMoreBtn);

  // Create "Learn More" button for locations/moon
  const locationLearnMoreBtn = document.createElement("button");
  locationLearnMoreBtn.id = "locationLearnMoreBtn";
  locationLearnMoreBtn.textContent = "Learn More";
  locationLearnMoreBtn.style.cssText = `
    position: absolute;
    left: 20px;
    top: 280px;
    background-color: #4A90E2;
    color: white;
    border: none;
    border-radius: 5px;
    padding: 10px 20px;
    cursor: pointer;
    font-size: 14px;
    font-weight: bold;
    transition: all 0.3s ease;
    display: none;
    z-index: 999;
  `;
  locationLearnMoreBtn.addEventListener("mouseover", () => {
    locationLearnMoreBtn.style.backgroundColor = "#357ABD";
    locationLearnMoreBtn.style.transform = "translateY(-2px)";
  });
  locationLearnMoreBtn.addEventListener("mouseout", () => {
    locationLearnMoreBtn.style.backgroundColor = "#4A90E2";
    locationLearnMoreBtn.style.transform = "translateY(0)";
  });
  locationLearnMoreBtn.addEventListener("click", () => {
    if (zoomedButton === "moon") {
      alert("Learn more about the Moon! You can link this to more content or navigate to another page.");
    } else {
      alert("Learn more about this location! You can link this to more content or navigate to another page.");
    }
  });
  document.body.appendChild(locationLearnMoreBtn);

  setTimeout(() => {
    const buttons = document.querySelectorAll(".myButton");

    buttons.forEach(btn => {
      btn.style.display = "inline-block";

      btn.addEventListener("click", () => {
        const rect = btn.getBoundingClientRect();
        const btnX = rect.left + rect.width / 2;
        const btnY = rect.top + rect.height / 2;

        if (zoomedButton === btn) {
          // Zoom out - keep earth where it is
          targetZoomScale = 1;
          zoomCenterX = x;
          zoomCenterY = y;
          zooming = true;
          zoomedButton = null;

          // Hide all buttons during zoom transition
          buttons.forEach(b => (b.style.display = "none"));
          
          // Hide home button
          homeButton.style.display = "none";
        } else {
          // Zoom in on the button's position on earth
          targetZoomScale = 3;
          zoomCenterX = btnX;
          zoomCenterY = btnY;
          zooming = true;
          zoomedButton = btn;

          // Hide ALL buttons including the clicked one
          buttons.forEach(b => (b.style.display = "none"));
          
          // Show home button
          homeButton.style.display = "block";
        }
      });
    });
  }, 4000); 
});